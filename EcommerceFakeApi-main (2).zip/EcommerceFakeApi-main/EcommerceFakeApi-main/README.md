# EcommerceFakeApi
1. The live data is coming from FakeAPI
2. The project is developed using react's context and Css
3. It is just a practice project for revising context api in react
4. Feel free to use the code

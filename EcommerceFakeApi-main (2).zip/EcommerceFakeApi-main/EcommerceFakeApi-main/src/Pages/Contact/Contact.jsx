import React from 'react'

const Contact = () => {
  return (
    <div className='contact-wrapper'>
      <div className="contact-container paddings maxWidth">
        contact
      </div>
    </div>
  )
}

export default Contact
import React from 'react'
import './ShimmerHome.css'

const ShimmerHome = () => {
  return (
    <div className='shimmer-card-wrapper'>
        <div className="shimmer-container paddings maxWidth">
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
            <div className="shimmer-card">
                <div className="image-shimmer"></div>
                <div className="shimmer-details">
                    <div className="shimmer-title"></div>
                    <div className="shimmer-price"></div>
                </div>
            </div>
        </div>
    </div>
  )
}

export default ShimmerHome